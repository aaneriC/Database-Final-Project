DROP DATABASE IF EXISTS bc_escape_room;
CREATE DATABASE bc_escape_room
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;
USE bc_escape_room;

CREATE TABLE building (
    building_id INT PRIMARY KEY,
    building_code CHAR(1) NOT NULL UNIQUE,
    building_name VARCHAR(100) NOT NULL
);

CREATE TABLE floor (
    floor_id INT PRIMARY KEY,
    building_id INT NOT NULL,
    floor_number TINYINT NOT NULL,
    floor_name VARCHAR(100) NOT NULL,
    CONSTRAINT uq_floor_building_number UNIQUE (building_id, floor_number),
    CONSTRAINT chk_floor_number CHECK (floor_number BETWEEN 1 AND 10),
    CONSTRAINT fk_floor_building
        FOREIGN KEY (building_id) REFERENCES building(building_id)
        ON DELETE RESTRICT
);

CREATE TABLE room (
    room_id INT PRIMARY KEY,
    floor_id INT NOT NULL,
    room_code VARCHAR(20) NOT NULL UNIQUE,
    room_name VARCHAR(100) NOT NULL,
    room_type VARCHAR(30) NOT NULL,
    security_level TINYINT NOT NULL,
    requires_explicit_permission BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT chk_room_type CHECK (room_type IN (
        'STORAGE', 'PANTRY', 'DINING_AREA', 'AUDITORIUM', 'LOUNGE',
        'MEETING_ROOM', 'OFFICE', 'MANAGER_OFFICE', 'EXECUTIVE_OFFICE',
        'LAB', 'EQUIPMENT_ROOM'
    )),
    CONSTRAINT chk_room_security CHECK (security_level BETWEEN 1 AND 5),
    CONSTRAINT fk_room_floor
        FOREIGN KEY (floor_id) REFERENCES floor(floor_id)
        ON DELETE RESTRICT
);

CREATE TABLE access_point (
    access_point_id INT PRIMARY KEY,
    building_id INT NOT NULL,
    floor_id INT NULL,
    room_id INT NULL,
    access_point_code VARCHAR(40) NOT NULL UNIQUE,
    access_point_name VARCHAR(120) NOT NULL,
    access_point_type VARCHAR(30) NOT NULL,
    CONSTRAINT chk_access_point_type CHECK (access_point_type IN (
        'BUILDING_ENTRANCE', 'BUILDING_EXIT', 'ELEVATOR_PANEL',
        'FLOOR_GATE', 'ROOM_DOOR'
    )),
    CONSTRAINT fk_access_point_building
        FOREIGN KEY (building_id) REFERENCES building(building_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_access_point_floor
        FOREIGN KEY (floor_id) REFERENCES floor(floor_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_access_point_room
        FOREIGN KEY (room_id) REFERENCES room(room_id)
        ON DELETE RESTRICT
);

CREATE TABLE employee (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    job_title VARCHAR(100) NOT NULL,
    employment_status VARCHAR(20) NOT NULL,
    CONSTRAINT chk_employee_status CHECK (
        employment_status IN ('ACTIVE', 'LEAVE', 'CONTRACT_ENDED', 'TERMINATED')
    )
);

CREATE TABLE badge (
    badge_id VARCHAR(12) PRIMARY KEY,
    employee_id INT NOT NULL UNIQUE,
    badge_status VARCHAR(20) NOT NULL,
    issued_at DATETIME NOT NULL,
    expires_at DATETIME NULL,
    CONSTRAINT chk_badge_status CHECK (
        badge_status IN ('ACTIVE', 'SUSPENDED', 'REVOKED', 'EXPIRED')
    ),
    CONSTRAINT chk_badge_dates CHECK (
        expires_at IS NULL OR expires_at > issued_at
    ),
    CONSTRAINT fk_badge_employee
        FOREIGN KEY (employee_id) REFERENCES employee(employee_id)
        ON DELETE RESTRICT
);

CREATE TABLE badge_permission (
    permission_id INT PRIMARY KEY,
    badge_id VARCHAR(12) NOT NULL,
    scope_type VARCHAR(10) NOT NULL,
    building_id INT NULL,
    floor_id INT NULL,
    room_id INT NULL,
    permission_status VARCHAR(20) NOT NULL,
    valid_from DATETIME NOT NULL,
    valid_until DATETIME NULL,
    CONSTRAINT chk_permission_scope CHECK (scope_type IN ('BUILDING', 'FLOOR', 'ROOM')),
    CONSTRAINT chk_permission_status CHECK (
        permission_status IN ('ACTIVE', 'REVOKED', 'EXPIRED')
    ),
    CONSTRAINT chk_permission_dates CHECK (
        valid_until IS NULL OR valid_until > valid_from
    ),
    CONSTRAINT chk_permission_target CHECK (
        (scope_type = 'BUILDING' AND building_id IS NOT NULL AND floor_id IS NULL AND room_id IS NULL)
        OR
        (scope_type = 'FLOOR' AND building_id IS NULL AND floor_id IS NOT NULL AND room_id IS NULL)
        OR
        (scope_type = 'ROOM' AND building_id IS NULL AND floor_id IS NULL AND room_id IS NOT NULL)
    ),
    CONSTRAINT fk_permission_badge
        FOREIGN KEY (badge_id) REFERENCES badge(badge_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_permission_building
        FOREIGN KEY (building_id) REFERENCES building(building_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_permission_floor
        FOREIGN KEY (floor_id) REFERENCES floor(floor_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_permission_room
        FOREIGN KEY (room_id) REFERENCES room(room_id)
        ON DELETE RESTRICT
);

CREATE TABLE access_event (
    event_id BIGINT PRIMARY KEY,
    access_point_id INT NOT NULL,
    badge_id VARCHAR(12) NULL,
    destination_floor_id INT NULL,
    event_time DATETIME NOT NULL,
    event_action VARCHAR(30) NOT NULL,
    access_decision VARCHAR(10) NOT NULL,
    matched_permission_id INT NULL,
    CONSTRAINT chk_event_action CHECK (event_action IN (
        'SWIPE_IN', 'SWIPE_OUT', 'SELECT_FLOOR', 'ENTER_FLOOR', 'DOOR_OPEN'
    )),
    CONSTRAINT chk_access_decision CHECK (
        access_decision IN ('GRANTED', 'DENIED')
    ),
    CONSTRAINT fk_event_access_point
        FOREIGN KEY (access_point_id) REFERENCES access_point(access_point_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_event_badge
        FOREIGN KEY (badge_id) REFERENCES badge(badge_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_event_destination_floor
        FOREIGN KEY (destination_floor_id) REFERENCES floor(floor_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_event_permission
        FOREIGN KEY (matched_permission_id) REFERENCES badge_permission(permission_id)
        ON DELETE RESTRICT
);

CREATE INDEX idx_access_event_point_time
    ON access_event(access_point_id, event_time);

CREATE INDEX idx_access_event_badge_time
    ON access_event(badge_id, event_time);

CREATE INDEX idx_permission_badge_scope
    ON badge_permission(badge_id, scope_type, permission_status, valid_from, valid_until);

