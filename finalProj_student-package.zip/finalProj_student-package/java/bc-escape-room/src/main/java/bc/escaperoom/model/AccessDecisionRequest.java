package bc.escaperoom.model;

import java.time.LocalDateTime;

public record AccessDecisionRequest(
        String badgeId,
        int accessPointId,
        LocalDateTime accessTime
) {
}
