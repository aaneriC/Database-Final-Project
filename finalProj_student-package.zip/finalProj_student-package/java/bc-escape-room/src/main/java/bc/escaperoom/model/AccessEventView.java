package bc.escaperoom.model;

import java.time.LocalDateTime;

public record AccessEventView(
        long eventId,
        String badgeId,
        int accessPointId,
        String accessPointCode,
        String accessPointName,
        String eventAction,
        String accessDecision,
        LocalDateTime eventTime,
        Integer destinationFloorNumber,
        Integer matchedPermissionId
) {
}
