package bc.escaperoom.dao;

import bc.escaperoom.model.AccessEventView;
import bc.escaperoom.model.AccessPoint;
import bc.escaperoom.model.BadgeSummary;
import bc.escaperoom.model.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LookupDao {
    private final Connection connection;

    public LookupDao(Connection connection) {
        this.connection = connection;
    }

    public Employee findEmployee(int employeeId) throws SQLException {
        String sql = """
                SELECT employee_id, employee_name, department, job_title, employment_status
                FROM employee
                WHERE employee_id = ?
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                return new Employee(
                        resultSet.getInt("employee_id"),
                        resultSet.getString("employee_name"),
                        resultSet.getString("department"),
                        resultSet.getString("job_title"),
                        resultSet.getString("employment_status")
                );
            }
        }
    }

    public BadgeSummary findBadge(String badgeId) throws SQLException {
        String sql = """
                SELECT b.badge_id, b.employee_id, e.employee_name,
                       b.badge_status, b.issued_at, b.expires_at
                FROM badge b
                JOIN employee e ON e.employee_id = b.employee_id
                WHERE b.badge_id = ?
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, badgeId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                return new BadgeSummary(
                        resultSet.getString("badge_id"),
                        resultSet.getInt("employee_id"),
                        resultSet.getString("employee_name"),
                        resultSet.getString("badge_status"),
                        resultSet.getTimestamp("issued_at").toLocalDateTime(),
                        resultSet.getTimestamp("expires_at") == null
                                ? null : resultSet.getTimestamp("expires_at").toLocalDateTime()
                );
            }
        }
    }

    public AccessPoint findAccessPoint(int accessPointId) throws SQLException {
        String sql = """
                SELECT ap.access_point_id, ap.access_point_code, ap.access_point_name,
                       ap.access_point_type, b.building_code, f.floor_number,
                       ap.floor_id, ap.room_id, r.room_code, r.room_type,
                       COALESCE(r.requires_explicit_permission, FALSE) AS requires_explicit_permission
                FROM access_point ap
                JOIN building b ON b.building_id = ap.building_id
                LEFT JOIN floor f ON f.floor_id = ap.floor_id
                LEFT JOIN room r ON r.room_id = ap.room_id
                WHERE ap.access_point_id = ?
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, accessPointId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                return new AccessPoint(
                        resultSet.getInt("access_point_id"),
                        resultSet.getString("access_point_code"),
                        resultSet.getString("access_point_name"),
                        resultSet.getString("access_point_type"),
                        resultSet.getString("building_code"),
                        getNullableInt(resultSet, "floor_number"),
                        getNullableInt(resultSet, "floor_id"),
                        getNullableInt(resultSet, "room_id"),
                        resultSet.getString("room_code"),
                        resultSet.getString("room_type"),
                        resultSet.getBoolean("requires_explicit_permission")
                );
            }
        }
    }

    public List<AccessEventView> findEventsByBadge(String badgeId, int requestedLimit) throws SQLException {
        int limit = Math.max(1, Math.min(requestedLimit, 500));
        String sql = """
                SELECT ae.event_id, ae.badge_id, ae.access_point_id,
                       ap.access_point_code, ap.access_point_name,
                       ae.event_action, ae.access_decision, ae.event_time,
                       destination.floor_number AS destination_floor_number,
                       ae.matched_permission_id
                FROM access_event ae
                JOIN access_point ap ON ap.access_point_id = ae.access_point_id
                LEFT JOIN floor destination ON destination.floor_id = ae.destination_floor_id
                WHERE ae.badge_id = ?
                ORDER BY ae.event_time, ae.event_id
                LIMIT ?
                """;
        List<AccessEventView> events = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, badgeId);
            statement.setInt(2, limit);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    events.add(new AccessEventView(
                            resultSet.getLong("event_id"),
                            resultSet.getString("badge_id"),
                            resultSet.getInt("access_point_id"),
                            resultSet.getString("access_point_code"),
                            resultSet.getString("access_point_name"),
                            resultSet.getString("event_action"),
                            resultSet.getString("access_decision"),
                            resultSet.getTimestamp("event_time").toLocalDateTime(),
                            getNullableInt(resultSet, "destination_floor_number"),
                            getNullableInt(resultSet, "matched_permission_id")
                    ));
                }
            }
        }
        return events;
    }

    private Integer getNullableInt(ResultSet resultSet, String column) throws SQLException {
        int value = resultSet.getInt(column);
        return resultSet.wasNull() ? null : value;
    }
}
