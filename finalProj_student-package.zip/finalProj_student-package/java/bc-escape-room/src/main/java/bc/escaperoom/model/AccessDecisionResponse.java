package bc.escaperoom.model;

import java.time.LocalDateTime;

public record AccessDecisionResponse(
        String badgeId,
        int accessPointId,
        String accessPointCode,
        LocalDateTime accessTime,
        boolean authorized,
        String decision,
        Integer matchedPermissionId,
        String reason
) {
}
