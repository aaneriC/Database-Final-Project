package bc.escaperoom.model;

import java.time.LocalDateTime;

public record BadgeSummary(
        String badgeId,
        int employeeId,
        String employeeName,
        String badgeStatus,
        LocalDateTime issuedAt,
        LocalDateTime expiresAt
) {
}
