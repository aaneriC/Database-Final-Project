package bc.escaperoom.model;

public record Employee(
        int employeeId,
        String employeeName,
        String department,
        String jobTitle,
        String employmentStatus
) {
}
