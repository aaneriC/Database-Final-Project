package bc.escaperoom.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscapeRoomApplication {
    public static void main(String[] args) {
        SpringApplication.run(EscapeRoomApplication.class, args);
    }
}
