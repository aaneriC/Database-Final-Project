package bc.escaperoom.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DbConnection {
    private static final String url = "jdbc:mysql://localhost:3306/bc_escape_room";
    private static final String user = "root";
    private static final String password = "rootroot";


    public static Connection open() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}
