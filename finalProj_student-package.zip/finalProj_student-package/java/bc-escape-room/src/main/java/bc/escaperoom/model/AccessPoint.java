package bc.escaperoom.model;

public record AccessPoint(
        int accessPointId,
        String accessPointCode,
        String accessPointName,
        String accessPointType,
        String buildingCode,
        Integer floorNumber,
        Integer floorId,
        Integer roomId,
        String roomCode,
        String roomType,
        boolean requiresExplicitPermission
) {
}
