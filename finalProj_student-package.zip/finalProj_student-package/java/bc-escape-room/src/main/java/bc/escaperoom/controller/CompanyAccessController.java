package bc.escaperoom.controller;

import bc.escaperoom.config.DbConnection;
import bc.escaperoom.dao.AccessDecisionDao;
import bc.escaperoom.dao.LookupDao;
import bc.escaperoom.model.AccessDecisionRequest;
import bc.escaperoom.model.AccessDecisionResponse;
import bc.escaperoom.model.AccessEventView;
import bc.escaperoom.model.AccessPoint;
import bc.escaperoom.model.BadgeSummary;
import bc.escaperoom.model.Employee;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CompanyAccessController {

    @GetMapping("/health")
    public Map<String, String> health() throws Exception {
        try (Connection connection = DbConnection.open();
             PreparedStatement statement = connection.prepareStatement("SELECT DATABASE()");
             ResultSet resultSet = statement.executeQuery()) {
            resultSet.next();
            return Map.of(
                    "application", "running",
                    "database", resultSet.getString(1),
                    "connection", "connected"
            );
        }
    }

    @GetMapping("/employees/{employeeId}")
    public ResponseEntity<Employee> employee(@PathVariable int employeeId) throws Exception {
        try (Connection connection = DbConnection.open()) {
            Employee employee = new LookupDao(connection).findEmployee(employeeId);
            return employee == null
                    ? ResponseEntity.notFound().build()
                    : ResponseEntity.ok(employee);
        }
    }

    @GetMapping("/badges/{badgeId}")
    public ResponseEntity<BadgeSummary> badge(@PathVariable String badgeId) throws Exception {
        try (Connection connection = DbConnection.open()) {
            BadgeSummary badge = new LookupDao(connection).findBadge(badgeId);
            return badge == null
                    ? ResponseEntity.notFound().build()
                    : ResponseEntity.ok(badge);
        }
    }

    @GetMapping("/access-points/{accessPointId}")
    public ResponseEntity<AccessPoint> accessPoint(@PathVariable int accessPointId) throws Exception {
        try (Connection connection = DbConnection.open()) {
            AccessPoint accessPoint = new LookupDao(connection).findAccessPoint(accessPointId);
            return accessPoint == null
                    ? ResponseEntity.notFound().build()
                    : ResponseEntity.ok(accessPoint);
        }
    }

    @GetMapping("/access-events/by-badge/{badgeId}")
    public List<AccessEventView> eventsByBadge(
            @PathVariable String badgeId,
            @RequestParam(defaultValue = "100") int limit
    ) throws Exception {
        try (Connection connection = DbConnection.open()) {
            return new LookupDao(connection).findEventsByBadge(badgeId, limit);
        }
    }

    @PostMapping("/access/authorize")
    public AccessDecisionResponse authorize(
            @RequestBody AccessDecisionRequest request
    ) throws Exception {
        try (Connection connection = DbConnection.open()) {
            return new AccessDecisionDao(connection).authorize(request);
        }
    }
}
