# ECE 4990 Database Escape Room

Work in your assigned three-person team. Read the project announcement before
changing any source file.

## Package contents

- `database/schema.sql` — creates the `ece_escape_room` database and tables.
- `database/seed.sql` — loads the complete synthetic investigation dataset.
- `java/escape-room-access-system` — supplied Maven/Spring Boot application
  using JDBC and DAO classes.
- `postman/ECE_4990_Escape_Room.postman_collection.json` — ready-to-run API
  requests.
- `postman/ECE_4990_Local.postman_environment.json` — local base URL.

## Recommended start order

1. Run `schema.sql` in MySQL Workbench.
2. Run `seed.sql` in MySQL Workbench.
3. Open the Java project in IntelliJ as a Maven project.
4. Configure the MySQL environment variables described in the Java README.
5. Start `EscapeRoomApplication`.
6. Import the Postman collection and environment.
7. Investigate with SQL first; then repair the authorization logic.

All people, badge records, events, and organizations in this project are
synthetic and created only for this course.
