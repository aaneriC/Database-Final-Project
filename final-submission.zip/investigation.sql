-- =====================================================================
-- ECE 4990 Final Project - Phase 1 investigation queries
-- Case: missing Roadster blueprint, storage room C-09-S17, 2026-10-31
-- Run AFTER schema.sql and seed.sql. Queries are in executable order and
-- read-only (SELECT only). Compatible with MySQL 8 (window functions/CTEs).
-- =====================================================================
USE bc_escape_room;

-- ---------------------------------------------------------------------
-- Q1. Sanity check: row counts of the loaded data.
-- ---------------------------------------------------------------------
SELECT 'building' AS tbl, COUNT(*) AS n FROM building
UNION ALL SELECT 'floor', COUNT(*) FROM floor
UNION ALL SELECT 'room', COUNT(*) FROM room
UNION ALL SELECT 'access_point', COUNT(*) FROM access_point
UNION ALL SELECT 'employee', COUNT(*) FROM employee
UNION ALL SELECT 'badge', COUNT(*) FROM badge
UNION ALL SELECT 'badge_permission', COUNT(*) FROM badge_permission
UNION ALL SELECT 'access_event', COUNT(*) FROM access_event;

-- ---------------------------------------------------------------------
-- Q2. Locate the crime scene: room C-09-S17 and its door access point.
-- ---------------------------------------------------------------------
SELECT r.room_id, r.room_code, r.room_name, r.room_type, r.security_level,
       r.requires_explicit_permission,
       f.floor_id, f.floor_number, b.building_code,
       ap.access_point_id, ap.access_point_code, ap.access_point_type
FROM room r
JOIN floor f         ON f.floor_id = r.floor_id
JOIN building b      ON b.building_id = f.building_id
JOIN access_point ap ON ap.room_id = r.room_id
WHERE r.room_code = 'C-09-S17';

-- ---------------------------------------------------------------------
-- Q3. Every door event of the storage room during the incident window
--     (blueprint last seen 18:00, theft discovered 20:10).
--     badge_id is NULL on this legacy door, so these are anonymous.
-- ---------------------------------------------------------------------
SELECT e.event_id, e.event_time, e.badge_id, e.event_action,
       e.access_decision, e.matched_permission_id
FROM access_event e
JOIN access_point ap ON ap.access_point_id = e.access_point_id
WHERE ap.access_point_code = 'C-09-S17-DOOR'
  AND e.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 20:10:00'
ORDER BY e.event_time;

-- ---------------------------------------------------------------------
-- Q4. Who is *supposed* to be able to open the storage room?
--     All ROOM permissions on C-09-S17 with status and validity.
--     One row is REVOKED and already ended on 2026-10-30.
-- ---------------------------------------------------------------------
SELECT bp.permission_id, bp.badge_id, e.employee_id, e.employee_name,
       e.department, bp.permission_status, bp.valid_from, bp.valid_until
FROM badge_permission bp
JOIN room r     ON r.room_id = bp.room_id
JOIN badge b    ON b.badge_id = bp.badge_id
JOIN employee e ON e.employee_id = b.employee_id
WHERE r.room_code = 'C-09-S17'
ORDER BY bp.permission_id;

-- ---------------------------------------------------------------------
-- Q5. Identified (badge) evidence on Floor 9 of Building C in the window:
--     who selected floor 9 / entered floor 9 / used the floor-9 elevator
--     panel. Anonymous events cannot be matched to a person alone, so we
--     start from the people that are provably around the storage room.
-- ---------------------------------------------------------------------
SELECT e.badge_id, emp.employee_name, emp.department,
       MIN(e.event_time) AS first_floor9_evidence,
       MAX(e.event_time) AS last_floor9_evidence,
       COUNT(*)          AS floor9_events
FROM access_event e
JOIN access_point ap ON ap.access_point_id = e.access_point_id
JOIN badge b         ON b.badge_id = e.badge_id
JOIN employee emp    ON emp.employee_id = b.employee_id
WHERE e.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 20:10:00'
  AND ap.building_id = 3
  AND ( (ap.access_point_type IN ('FLOOR_GATE', 'ELEVATOR_PANEL') AND ap.floor_id = 309)
        OR e.destination_floor_id = 309 )
GROUP BY e.badge_id, emp.employee_name, emp.department
ORDER BY first_floor9_evidence;

-- ---------------------------------------------------------------------
-- Q6. Who actually LEFT Building C after the blueprint was last seen?
--     The item was carried out of the building, so the thief must have a
--     building exit (or be unaccounted for) after 18:00.
-- ---------------------------------------------------------------------
SELECT e.event_id, e.event_time, e.badge_id, emp.employee_name,
       ap.access_point_code, e.event_action, e.access_decision
FROM access_event e
JOIN access_point ap ON ap.access_point_id = e.access_point_id
LEFT JOIN badge b    ON b.badge_id = e.badge_id
LEFT JOIN employee emp ON emp.employee_id = b.employee_id
WHERE ap.building_id = 3
  AND ap.access_point_type IN ('BUILDING_ENTRANCE', 'BUILDING_EXIT')
  AND e.event_time >= '2026-10-31 18:00:00'
ORDER BY e.event_time;

-- ---------------------------------------------------------------------
-- Q7. Candidate comparison (all Floor-9 candidates from Q5).
--     For each: S17 permission, whether they ever exited Building C,
--     time on floor 9, and which anonymous S17 events fit them.
-- ---------------------------------------------------------------------
WITH cand AS (
    SELECT DISTINCT e.badge_id
    FROM access_event e
    JOIN access_point ap ON ap.access_point_id = e.access_point_id
    WHERE e.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 20:10:00'
      AND ap.building_id = 3
      AND e.badge_id IS NOT NULL
      AND ( (ap.access_point_type IN ('FLOOR_GATE', 'ELEVATOR_PANEL') AND ap.floor_id = 309)
            OR e.destination_floor_id = 309 )
)
SELECT c.badge_id, emp.employee_id, emp.employee_name, emp.department, emp.job_title,
       (SELECT GROUP_CONCAT(CONCAT(bp.permission_id, ':', bp.permission_status)
                            ORDER BY bp.permission_id SEPARATOR ', ')
          FROM badge_permission bp
         WHERE bp.badge_id = c.badge_id AND bp.room_id = 309017) AS s17_permission,
       (SELECT COUNT(*)
          FROM access_event x
          JOIN access_point xa ON xa.access_point_id = x.access_point_id
         WHERE x.badge_id = c.badge_id AND xa.access_point_type = 'BUILDING_EXIT'
           AND x.event_time >= '2026-10-31 18:00:00') AS building_exits_after_6pm,
       (SELECT MIN(x.event_time) FROM access_event x
         WHERE x.badge_id = c.badge_id AND x.access_point_id = 30901
           AND x.event_time >= '2026-10-31 18:00:00') AS first_floor9_gate_after_6pm,
       (SELECT MAX(x.event_time) FROM access_event x
         WHERE x.badge_id = c.badge_id
           AND x.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 23:59:59') AS last_logged_event
FROM cand c
JOIN badge b      ON b.badge_id = c.badge_id
JOIN employee emp ON emp.employee_id = b.employee_id
ORDER BY building_exits_after_6pm DESC, c.badge_id;

-- ---------------------------------------------------------------------
-- Q8. Full identified (direct) trail of the prime suspect BC-0817.
-- ---------------------------------------------------------------------
SELECT e.event_id, e.event_time, e.access_point_id, ap.access_point_code,
       ap.access_point_name, e.event_action, e.access_decision,
       e.destination_floor_id, e.matched_permission_id
FROM access_event e
JOIN access_point ap ON ap.access_point_id = e.access_point_id
WHERE e.badge_id = 'BC-0817'
ORDER BY e.event_time, e.event_id;

-- ---------------------------------------------------------------------
-- Q9. Suspect identity.
-- ---------------------------------------------------------------------
SELECT emp.employee_name, emp.employee_id, b.badge_id, emp.department,
       emp.job_title, emp.employment_status, b.badge_status
FROM badge b
JOIN employee emp ON emp.employee_id = b.employee_id
WHERE b.badge_id = 'BC-0817';

-- ---------------------------------------------------------------------
-- Q10. COMPLETE ROUTE of BC-0817, building entry -> final building exit,
--      labelled DIRECT (badge id present) or INFERRED (anonymous door
--      event placed between identified events).
--
--  Inference rule for an anonymous ROOM_DOOR event A (Building C, time t,
--  inside the incident window 18:00-20:10; the blueprint was still in place
--  at 18:00 so earlier anonymous traffic is irrelevant):
--    P = suspect's last identified event at/before t (ties by event_id)
--    N = suspect's first identified event after t
--    1. LOCATION: A's floor must equal the floor the suspect is on right
--       after P (destination floor for SELECT_FLOOR, else P's floor) AND
--       t - P <= @gap_min minutes   ("suspect just arrived/was there"), OR
--       A's floor must equal N's access-point floor AND N - t <= @gap_min
--       ("suspect is standing on that floor right before N").
--    2. EXCLUSIVITY: no OTHER identified badge entered/selected that floor
--       within @gap_min minutes before t (otherwise A is explained by them).
--    Anything failing both is not attributed to the suspect.
-- ---------------------------------------------------------------------
SET @gap_min = 10;

WITH suspect AS (
    SELECT e.event_id, e.event_time, e.access_point_id, e.event_action,
           e.access_decision, e.destination_floor_id,
           ap.access_point_code, ap.access_point_name, ap.floor_id AS ap_floor,
           CASE WHEN e.event_action = 'SELECT_FLOOR' THEN e.destination_floor_id
                ELSE ap.floor_id END AS floor_after
    FROM access_event e
    JOIN access_point ap ON ap.access_point_id = e.access_point_id
    WHERE e.badge_id = 'BC-0817'
      AND e.event_time >= (SELECT MIN(x.event_time) FROM access_event x
                           WHERE x.badge_id = 'BC-0817'
                             AND x.access_point_id = 3001)          -- building entry
      AND e.event_time <= (SELECT MAX(x.event_time) FROM access_event x
                           WHERE x.badge_id = 'BC-0817'
                             AND x.access_point_id = 3002)          -- building exit
),
anon AS (
    SELECT e.event_id, e.event_time, e.access_point_id, e.event_action,
           e.access_decision, ap.access_point_code, ap.access_point_name,
           ap.floor_id AS ap_floor
    FROM access_event e
    JOIN access_point ap ON ap.access_point_id = e.access_point_id
    WHERE e.badge_id IS NULL
      AND ap.building_id = 3
      AND ap.access_point_type = 'ROOM_DOOR'
      AND e.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 20:10:00'
),
fit AS (
    SELECT a.*,
           (SELECT s.event_id FROM suspect s
             WHERE (s.event_time, s.event_id) <= (a.event_time, a.event_id)
             ORDER BY s.event_time DESC, s.event_id DESC LIMIT 1) AS prev_id,
           (SELECT s.event_id FROM suspect s
             WHERE (s.event_time, s.event_id) >  (a.event_time, a.event_id)
             ORDER BY s.event_time, s.event_id LIMIT 1) AS next_id
    FROM anon a
),
inferred AS (
    SELECT f.event_id, f.event_time, f.access_point_id, f.access_point_code,
           f.access_point_name, f.event_action, f.access_decision,
           'INFERRED (anonymous)' AS evidence_type,
           CONCAT('Door is on floor ', fl.floor_number, '. ',
                  CASE WHEN p.floor_after = f.ap_floor
                            AND TIMESTAMPDIFF(MINUTE, p.event_time, f.event_time) <= @gap_min
                       THEN CONCAT('Previous identified event #', p.event_id, ' (',
                                   p.access_point_code, ' at ', TIME(p.event_time),
                                   ') put the suspect on this floor ',
                                   TIMESTAMPDIFF(MINUTE, p.event_time, f.event_time), ' min earlier. ')
                       ELSE '' END,
                  CASE WHEN n.ap_floor = f.ap_floor
                            AND TIMESTAMPDIFF(MINUTE, f.event_time, n.event_time) <= @gap_min
                       THEN CONCAT('Next identified event #', n.event_id, ' (',
                                   n.access_point_code, ' at ', TIME(n.event_time),
                                   ') is on this floor ',
                                   TIMESTAMPDIFF(MINUTE, f.event_time, n.event_time), ' min later. ')
                       ELSE '' END,
                  'No other identified badge arrived on this floor in the prior ',
                  @gap_min, ' min.') AS explanation
    FROM fit f
    JOIN suspect p ON p.event_id = f.prev_id
    JOIN suspect n ON n.event_id = f.next_id
    JOIN floor fl  ON fl.floor_id = f.ap_floor
    WHERE ( (p.floor_after = f.ap_floor
             AND TIMESTAMPDIFF(MINUTE, p.event_time, f.event_time) <= @gap_min)
         OR (n.ap_floor = f.ap_floor
             AND TIMESTAMPDIFF(MINUTE, f.event_time, n.event_time) <= @gap_min) )
      AND NOT EXISTS (
            SELECT 1
            FROM access_event o
            JOIN access_point oa ON oa.access_point_id = o.access_point_id
            WHERE o.badge_id IS NOT NULL
              AND o.badge_id <> 'BC-0817'
              AND oa.building_id = 3
              AND ( (oa.access_point_type IN ('FLOOR_GATE', 'ELEVATOR_PANEL')
                     AND oa.floor_id = f.ap_floor)
                    OR o.destination_floor_id = f.ap_floor )
              AND o.event_time BETWEEN f.event_time - INTERVAL @gap_min MINUTE
                                   AND f.event_time )
),
direct AS (
    SELECT s.event_id, s.event_time, s.access_point_id, s.access_point_code,
           s.access_point_name, s.event_action, s.access_decision,
           'DIRECT (badge BC-0817)' AS evidence_type,
           'Badge id recorded on the event' AS explanation
    FROM suspect s
)
SELECT event_time, access_point_id, access_point_code, access_point_name,
       event_action, access_decision, evidence_type, explanation, event_id
FROM (SELECT * FROM direct UNION ALL SELECT * FROM inferred) route
ORDER BY event_time, event_id;

-- ---------------------------------------------------------------------
-- Q11. Attribution of EVERY anonymous S17 door event in the window:
--      which identified badge is the best explanation?
--      * 'arrived_floor9_badge' = the latest badge that came through the
--        floor-9 gate / selected floor 9 in the 10 minutes before the event.
--      * Events 19:48 and 19:51 have nobody arriving, but the suspect's own
--        next identified event (19:52, floor-9 elevator panel) is 1-4 min later.
--      * Events 19:59 and 20:04 are impossible for the suspect: he is
--        on floor 4 (19:58 gate, 19:59 office door) and floor 1 (20:04 gate).
-- ---------------------------------------------------------------------
SELECT a.event_id, a.event_time AS s17_event_time,
       (SELECT CONCAT(o.badge_id, ' @ ', TIME(o.event_time))
          FROM access_event o
         WHERE o.access_point_id = 30901 AND o.badge_id IS NOT NULL
           AND o.event_time BETWEEN a.event_time - INTERVAL 10 MINUTE AND a.event_time
         ORDER BY o.event_time DESC, o.event_id DESC LIMIT 1) AS arrived_floor9_badge,
       (SELECT CONCAT(xa.access_point_code, ' @ ', TIME(x.event_time))
          FROM access_event x
          JOIN access_point xa ON xa.access_point_id = x.access_point_id
         WHERE x.badge_id = 'BC-0817'
           AND (x.event_time, x.event_id) <= (a.event_time, a.event_id)
         ORDER BY x.event_time DESC, x.event_id DESC LIMIT 1) AS suspect_prev_event,
       (SELECT CONCAT(xa.access_point_code, ' @ ', TIME(x.event_time))
          FROM access_event x
          JOIN access_point xa ON xa.access_point_id = x.access_point_id
         WHERE x.badge_id = 'BC-0817'
           AND (x.event_time, x.event_id) > (a.event_time, a.event_id)
         ORDER BY x.event_time, x.event_id LIMIT 1) AS suspect_next_event
FROM access_event a
WHERE a.access_point_id = 309017
  AND a.event_time BETWEEN '2026-10-31 18:00:00' AND '2026-10-31 20:10:00'
ORDER BY a.event_time;

-- ---------------------------------------------------------------------
-- Q12. ROOT CAUSE evidence: replay the supplied DAO query for the suspect.
--      The legacy findMatchingPermission() had no status / validity filter:
--        SELECT permission_id FROM badge_permission
--        WHERE badge_id=? AND scope_type='ROOM' AND room_id=?
--        ORDER BY valid_from DESC LIMIT 1
--      It returns permission 1901 (REVOKED, ended 2026-10-30) -> GRANTED.
-- ---------------------------------------------------------------------
SELECT 'legacy DAO query' AS query_variant, permission_id, permission_status,
       valid_from, valid_until
FROM (SELECT permission_id, permission_status, valid_from, valid_until
        FROM badge_permission
       WHERE badge_id = 'BC-0817' AND scope_type = 'ROOM' AND room_id = 309017
       ORDER BY valid_from DESC LIMIT 1) legacy
UNION ALL
SELECT 'fixed query at 2026-10-31 19:51', bp.permission_id, bp.permission_status,
       bp.valid_from, bp.valid_until
FROM badge_permission bp
WHERE bp.badge_id = 'BC-0817' AND bp.scope_type = 'ROOM' AND bp.room_id = 309017
  AND bp.permission_status = 'ACTIVE'
  AND bp.valid_from <= '2026-10-31 19:51:00'
  AND (bp.valid_until IS NULL OR bp.valid_until >= '2026-10-31 19:51:00');

-- ---------------------------------------------------------------------
-- Q13. Scope of the defect: permission rows that are not currently valid
--      (non-ACTIVE, or already past valid_until at the incident time) but
--      which the legacy query would still honour.
-- ---------------------------------------------------------------------
SELECT permission_id, badge_id, scope_type, permission_status, valid_from, valid_until
FROM badge_permission
WHERE permission_status <> 'ACTIVE'
   OR valid_from  > '2026-10-31 19:51:00'
   OR valid_until < '2026-10-31 19:51:00'
ORDER BY permission_id;
