-- =====================================================================
-- ECE 4990 Final Project - Escape Room: The Missing Blueprint
-- Team BroncoDB - Investigation queries (run in this order)
-- Prerequisite: run database/schema.sql, then database/seed.sql
-- =====================================================================
USE bc_escape_room;

-- Incident window: blueprint last seen 18:00, missing at 20:10 on 2026-10-31.
SET @t_seen    = '2026-10-31 18:00:00';
SET @t_missing = '2026-10-31 20:10:00';
SET @room_code = 'C-09-S17-DOOR';

-- ---------------------------------------------------------------------
-- Q1. Identify the crime-scene door and the room behind it.
-- ---------------------------------------------------------------------
SELECT ap.access_point_id, ap.access_point_code, ap.access_point_name,
       ap.building_id, ap.floor_id, r.room_id, r.room_type,
       r.security_level, r.requires_explicit_permission
FROM access_point ap
JOIN room r ON r.room_id = ap.room_id
WHERE ap.access_point_code = @room_code;

SET @door_id = (SELECT access_point_id FROM access_point WHERE access_point_code = @room_code);
SET @room_id = (SELECT room_id         FROM access_point WHERE access_point_code = @room_code);
SET @floor_id = (SELECT floor_id       FROM access_point WHERE access_point_code = @room_code);
SET @bldg_id  = (SELECT building_id    FROM access_point WHERE access_point_code = @room_code);

-- ---------------------------------------------------------------------
-- Q2. Every event at the storage door that day.
--     All are anonymous (badge_id NULL) - legacy STORAGE doors do not log badges.
-- ---------------------------------------------------------------------
SELECT event_id, event_time, badge_id, event_action, access_decision, matched_permission_id
FROM access_event
WHERE access_point_id = @door_id
  AND DATE(event_time) = '2026-10-31'
ORDER BY event_time;

-- ---------------------------------------------------------------------
-- Q3. Who could legitimately open this door? Every permission ever issued on the room.
--     -> BC-0650, BC-0673, BC-0705 hold ACTIVE permissions;
--        BC-0817 holds permission 1901 which is REVOKED and expired 2026-10-30 23:59:59.
-- ---------------------------------------------------------------------
SELECT bp.permission_id, bp.badge_id, e.employee_id, e.employee_name, e.department,
       e.job_title, bp.permission_status, bp.valid_from, bp.valid_until
FROM badge_permission bp
JOIN badge b    ON b.badge_id = bp.badge_id
JOIN employee e ON e.employee_id = b.employee_id
WHERE bp.scope_type = 'ROOM' AND bp.room_id = @room_id
ORDER BY bp.badge_id;

-- ---------------------------------------------------------------------
-- Q4. Identified (badged) people who arrived on floor 9 of Building C
--     during the incident window (floor gate / elevator selecting floor 9).
-- ---------------------------------------------------------------------
SELECT ae.event_time, ae.badge_id, e.employee_name, e.department,
       ap.access_point_code, ae.event_action, ae.destination_floor_id
FROM access_event ae
JOIN access_point ap ON ap.access_point_id = ae.access_point_id
JOIN badge b         ON b.badge_id = ae.badge_id
JOIN employee e      ON e.employee_id = b.employee_id
WHERE ae.event_time BETWEEN @t_seen AND @t_missing
  AND ( (ap.floor_id = @floor_id AND ap.access_point_type IN ('FLOOR_GATE','ELEVATOR_PANEL'))
        OR ae.destination_floor_id = @floor_id )
ORDER BY ae.event_time;

-- ---------------------------------------------------------------------
-- Q5. Merged floor-9 timeline: storage-door openings interleaved with
--     identified floor-9 gate/elevator events (used to infer who opened the door).
-- ---------------------------------------------------------------------
SELECT ae.event_time, ae.event_id, COALESCE(ae.badge_id, '(anonymous)') AS badge_id,
       ap.access_point_code, ae.event_action, ae.access_decision,
       ae.destination_floor_id, ae.matched_permission_id
FROM access_event ae
JOIN access_point ap ON ap.access_point_id = ae.access_point_id
WHERE ae.event_time BETWEEN @t_seen AND @t_missing
  AND ( ae.access_point_id = @door_id
        OR (ap.floor_id = @floor_id AND ap.access_point_type IN ('FLOOR_GATE','ELEVATOR_PANEL'))
        OR ae.destination_floor_id = @floor_id )
ORDER BY ae.event_time;

-- ---------------------------------------------------------------------
-- Q6. The blueprint was carried OUT of the building shortly after the theft.
--     Who swiped out of (or back into) Building C after the item was last seen?
--     -> Only BC-0817 exits Building C (20:05).
-- ---------------------------------------------------------------------
SELECT ae.event_time, ae.badge_id, e.employee_name, e.department,
       ap.access_point_code, ae.event_action, ae.access_decision
FROM access_event ae
JOIN access_point ap ON ap.access_point_id = ae.access_point_id
LEFT JOIN badge b    ON b.badge_id = ae.badge_id
LEFT JOIN employee e ON e.employee_id = b.employee_id
WHERE ap.building_id = @bldg_id
  AND ap.access_point_type IN ('BUILDING_ENTRANCE', 'BUILDING_EXIT')
  AND ae.event_time >= @t_seen
ORDER BY ae.event_time;

-- ---------------------------------------------------------------------
-- Q7. Any permission in the system that is not ACTIVE or has already expired.
--     -> exactly one row: permission 1901 (BC-0817, room 309017, REVOKED).
-- ---------------------------------------------------------------------
SELECT permission_id, badge_id, scope_type, room_id, permission_status, valid_from, valid_until
FROM badge_permission
WHERE permission_status <> 'ACTIVE'
   OR (valid_until IS NOT NULL AND valid_until < @t_seen);

-- ---------------------------------------------------------------------
-- Q8. Suspect profile.
-- ---------------------------------------------------------------------
SET @suspect_badge = 'BC-0817';

SELECT e.employee_id, e.employee_name, e.department, e.job_title, e.employment_status,
       b.badge_id, b.badge_status, b.issued_at, b.expires_at
FROM badge b
JOIN employee e ON e.employee_id = b.employee_id
WHERE b.badge_id = @suspect_badge;

SELECT permission_id, scope_type, building_id, floor_id, room_id,
       permission_status, valid_from, valid_until
FROM badge_permission
WHERE badge_id = @suspect_badge
ORDER BY valid_from, permission_id;

-- ---------------------------------------------------------------------
-- Q9. Suspect's complete route: identified events (DIRECT) merged with the
--     anonymous storage-door events that fall inside the suspect's floor-9 visit (INFERRED).
-- ---------------------------------------------------------------------
SELECT ae.event_time, ae.event_id, ae.access_point_id, ap.access_point_code,
       ap.access_point_name, ae.event_action, ae.access_decision,
       ae.destination_floor_id, ae.matched_permission_id,
       CASE WHEN ae.badge_id IS NULL THEN 'INFERRED (anonymous)' ELSE 'DIRECT (badge)' END AS evidence
FROM access_event ae
JOIN access_point ap ON ap.access_point_id = ae.access_point_id
WHERE DATE(ae.event_time) = '2026-10-31'
  AND ( ae.badge_id = @suspect_badge
        OR ( ae.badge_id IS NULL
             AND ae.access_point_id = @door_id
             -- between the suspect's last return to floor 9 and leaving it by elevator at 19:52
             AND ae.event_time BETWEEN '2026-10-31 19:20:00' AND '2026-10-31 19:52:00'
             -- and not explained by another identified visitor already on the floor
             AND ae.event_time > '2026-10-31 19:37:00') )
ORDER BY ae.event_time;

-- ---------------------------------------------------------------------
-- Q10. Red-herring check: full-day routes of the other floor-9 visitors.
--      None of them exits Building C after the theft.
-- ---------------------------------------------------------------------
SELECT ae.badge_id, ae.event_time, ap.access_point_code, ae.event_action,
       ae.access_decision, ae.destination_floor_id
FROM access_event ae
JOIN access_point ap ON ap.access_point_id = ae.access_point_id
WHERE ae.badge_id IN ('BC-0650', 'BC-0673', 'BC-0705', 'BC-0755', 'BC-0788')
ORDER BY ae.badge_id, ae.event_time;

-- Summary table for the comparison.
SELECT b.badge_id, e.employee_name, e.department,
       MAX(CASE WHEN bp.room_id = @room_id THEN bp.permission_status END) AS s17_permission,
       MAX(CASE WHEN ap.floor_id = @floor_id AND ap.access_point_type = 'FLOOR_GATE'
                 AND ae.event_time <= @t_missing THEN ae.event_time END)   AS last_entered_floor9,
       SUM(ap.access_point_type = 'BUILDING_EXIT' AND ae.event_time >= @t_seen) AS building_exits_after_18
FROM badge b
JOIN employee e           ON e.employee_id = b.employee_id
LEFT JOIN badge_permission bp ON bp.badge_id = b.badge_id AND bp.room_id = @room_id
LEFT JOIN access_event ae ON ae.badge_id = b.badge_id
LEFT JOIN access_point ap ON ap.access_point_id = ae.access_point_id
WHERE b.badge_id IN ('BC-0650', 'BC-0673', 'BC-0705', 'BC-0755', 'BC-0788', 'BC-0817')
GROUP BY b.badge_id, e.employee_name, e.department
ORDER BY b.badge_id;

-- ---------------------------------------------------------------------
-- Q11. Root-cause evidence for Phase 2: the access events that relied on the suspect's
--      permissions, and what the ORIGINAL DAO query returns for the storage door.
--      Original query (no status / time check) still returns REVOKED permission 1901:
-- ---------------------------------------------------------------------
SELECT permission_id
FROM badge_permission
WHERE badge_id = @suspect_badge AND scope_type = 'ROOM' AND room_id = @room_id
ORDER BY valid_from DESC
LIMIT 1;

-- Corrected query (what the fixed AccessDecisionDao runs) returns no row -> DENIED:
SET @t_access = '2026-10-31 19:48:00';
SELECT permission_id
FROM badge_permission
WHERE badge_id = @suspect_badge AND scope_type = 'ROOM' AND room_id = @room_id
  AND permission_status = 'ACTIVE'
  AND valid_from <= @t_access
  AND (valid_until IS NULL OR valid_until >= @t_access)
ORDER BY valid_from DESC
LIMIT 1;
