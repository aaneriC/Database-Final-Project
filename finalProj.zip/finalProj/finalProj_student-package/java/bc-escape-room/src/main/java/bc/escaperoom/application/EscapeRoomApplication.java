package bc.escaperoom.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Controllers, DAOs, and the error handler live in sibling packages (bc.escaperoom.*),
// so component scanning must start at bc.escaperoom, not at this class's package.
@SpringBootApplication(scanBasePackages = "bc.escaperoom")
public class EscapeRoomApplication {
    public static void main(String[] args) {
        SpringApplication.run(EscapeRoomApplication.class, args);
    }
}
