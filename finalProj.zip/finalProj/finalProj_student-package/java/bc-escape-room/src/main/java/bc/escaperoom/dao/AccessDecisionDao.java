package bc.escaperoom.dao;

import bc.escaperoom.model.AccessDecisionRequest;
import bc.escaperoom.model.AccessDecisionResponse;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class AccessDecisionDao {
    private final Connection connection;

    public AccessDecisionDao(Connection connection) {
        this.connection = connection;
    }

    public AccessDecisionResponse authorize(AccessDecisionRequest request) throws SQLException {
        AccessTarget target = findTarget(request.accessPointId());
        if (target == null) {
            return denied(request, null, "Access point does not exist.");
        }

        if (request.badgeId() == null || request.badgeId().isBlank()) {
            return denied(request, target.accessPointCode(), "A badge ID is required.");
        }
        if (request.accessTime() == null) {
            return denied(request, target.accessPointCode(), "An access time is required.");
        }

        if (!isBadgeUsable(request.badgeId(), request.accessTime())) {
            return denied(request, target.accessPointCode(),
                    "Badge does not exist or is not active at the requested time.");
        }

        Integer permissionId = findMatchingPermission(
                request.badgeId(), target, request.accessTime());

        if (permissionId == null) {
            String reason = hasAnyPermissionForTarget(request.badgeId(), target)
                    ? "A " + target.scopeType() + " permission exists for this target, but it is "
                      + "revoked, expired, or not valid at the requested time."
                    : "No matching permission record was found.";
            return denied(request, target.accessPointCode(), reason);
        }

        return new AccessDecisionResponse(
                request.badgeId(),
                request.accessPointId(),
                target.accessPointCode(),
                request.accessTime(),
                true,
                "GRANTED",
                permissionId,
                "A matching " + target.scopeType() + " permission record was found."
        );
    }

    private AccessTarget findTarget(int accessPointId) throws SQLException {
        String sql = """
                SELECT ap.access_point_code, ap.access_point_type,
                       ap.building_id, ap.floor_id, ap.room_id,
                       COALESCE(r.requires_explicit_permission, FALSE) AS requires_explicit_permission
                FROM access_point ap
                LEFT JOIN room r ON r.room_id = ap.room_id
                WHERE ap.access_point_id = ?
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, accessPointId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                String accessPointType = resultSet.getString("access_point_type");
                if ("ROOM_DOOR".equals(accessPointType)
                        && resultSet.getBoolean("requires_explicit_permission")) {
                    return new AccessTarget(
                            resultSet.getString("access_point_code"),
                            "ROOM",
                            resultSet.getInt("room_id")
                    );
                }
                if ("FLOOR_GATE".equals(accessPointType)
                        || "ELEVATOR_PANEL".equals(accessPointType)) {
                    return new AccessTarget(
                            resultSet.getString("access_point_code"),
                            "FLOOR",
                            resultSet.getInt("floor_id")
                    );
                }
                return new AccessTarget(
                        resultSet.getString("access_point_code"),
                        "BUILDING",
                        resultSet.getInt("building_id")
                );
            }
        }
    }

    /**
     * The badge itself must be ACTIVE and inside its issued/expiry window at the access time.
     */
    private boolean isBadgeUsable(String badgeId, LocalDateTime accessTime) throws SQLException {
        String sql = """
                SELECT 1
                FROM badge
                WHERE badge_id = ?
                  AND badge_status = 'ACTIVE'
                  AND issued_at <= ?
                  AND (expires_at IS NULL OR expires_at > ?)
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            Timestamp at = Timestamp.valueOf(accessTime);
            statement.setString(1, badgeId);
            statement.setTimestamp(2, at);
            statement.setTimestamp(3, at);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    /**
     * Returns a permission only if it targets this scope, is ACTIVE, and its validity
     * window [valid_from, valid_until] contains the requested access time.
     * The original query matched on badge/scope/target only, so a REVOKED or
     * expired permission was still returned and access was GRANTED.
     */
    private Integer findMatchingPermission(
            String badgeId,
            AccessTarget target,
            LocalDateTime accessTime
    ) throws SQLException {
        String sql = "SELECT permission_id "
                + "FROM badge_permission "
                + "WHERE badge_id = ? "
                + "AND scope_type = ? "
                + "AND " + targetColumn(target) + " = ? "
                + "AND permission_status = 'ACTIVE' "
                + "AND valid_from <= ? "
                + "AND (valid_until IS NULL OR valid_until >= ?) "
                + "ORDER BY valid_from DESC "
                + "LIMIT 1";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            Timestamp at = Timestamp.valueOf(accessTime);
            statement.setString(1, badgeId);
            statement.setString(2, target.scopeType());
            statement.setInt(3, target.targetId());
            statement.setTimestamp(4, at);
            statement.setTimestamp(5, at);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt("permission_id") : null;
            }
        }
    }

    /** Used only to explain a denial: does any (possibly inactive) permission exist for this target? */
    private boolean hasAnyPermissionForTarget(String badgeId, AccessTarget target) throws SQLException {
        String sql = "SELECT 1 FROM badge_permission "
                + "WHERE badge_id = ? AND scope_type = ? AND " + targetColumn(target) + " = ? "
                + "LIMIT 1";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, badgeId);
            statement.setString(2, target.scopeType());
            statement.setInt(3, target.targetId());
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    private static String targetColumn(AccessTarget target) {
        return switch (target.scopeType()) {
            case "BUILDING" -> "building_id";
            case "FLOOR" -> "floor_id";
            case "ROOM" -> "room_id";
            default -> throw new IllegalArgumentException("Unsupported scope type");
        };
    }

    private AccessDecisionResponse denied(
            AccessDecisionRequest request,
            String accessPointCode,
            String reason
    ) {
        return new AccessDecisionResponse(
                request.badgeId(),
                request.accessPointId(),
                accessPointCode,
                request.accessTime(),
                false,
                "DENIED",
                null,
                reason
        );
    }

    private record AccessTarget(String accessPointCode, String scopeType, int targetId) {
    }
}
