package bc.escaperoom.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DbConnection {
    // Configure with the DB_URL, DB_USER, and DB_PASSWORD environment variables
    // (IntelliJ: Run > Edit Configurations > Environment variables).
    private static final String url = env("DB_URL", "jdbc:mysql://localhost:3306/bc_escape_room");
    private static final String user = env("DB_USER", "root");
    private static final String password = env("DB_PASSWORD", "");

    private DbConnection() {
    }

    public static Connection open() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    private static String env(String name, String fallback) {
        String value = System.getenv(name);
        return (value == null || value.isBlank()) ? fallback : value;
    }
}
